﻿namespace OsTask2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chLstBxCourse = new System.Windows.Forms.CheckedListBox();
            this.combxAdress = new System.Windows.Forms.ComboBox();
            this.rdFemale = new System.Windows.Forms.RadioButton();
            this.rdMale = new System.Windows.Forms.RadioButton();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.lblcoursses = new System.Windows.Forms.Label();
            this.lblAdress = new System.Windows.Forms.Label();
            this.lblGender = new System.Windows.Forms.Label();
            this.LblAge = new System.Windows.Forms.Label();
            this.LblName = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chLstBxCourse);
            this.groupBox1.Controls.Add(this.combxAdress);
            this.groupBox1.Controls.Add(this.rdFemale);
            this.groupBox1.Controls.Add(this.rdMale);
            this.groupBox1.Controls.Add(this.txtAge);
            this.groupBox1.Controls.Add(this.txtName);
            this.groupBox1.Controls.Add(this.btnSubmit);
            this.groupBox1.Controls.Add(this.lblcoursses);
            this.groupBox1.Controls.Add(this.lblAdress);
            this.groupBox1.Controls.Add(this.lblGender);
            this.groupBox1.Controls.Add(this.LblAge);
            this.groupBox1.Controls.Add(this.LblName);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(448, 449);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "main group";
            // 
            // chLstBxCourse
            // 
            this.chLstBxCourse.FormattingEnabled = true;
            this.chLstBxCourse.Items.AddRange(new object[] {
            "C",
            "C#",
            "C++",
            "Java",
            "Python",
            "AI",
            "Full stack"});
            this.chLstBxCourse.Location = new System.Drawing.Point(119, 228);
            this.chLstBxCourse.Name = "chLstBxCourse";
            this.chLstBxCourse.Size = new System.Drawing.Size(120, 94);
            this.chLstBxCourse.TabIndex = 11;
            // 
            // combxAdress
            // 
            this.combxAdress.FormattingEnabled = true;
            this.combxAdress.Items.AddRange(new object[] {
            "cairo",
            "mansoura ",
            "alexandria",
            "aswan",
            "tanta",
            "other"});
            this.combxAdress.Location = new System.Drawing.Point(119, 185);
            this.combxAdress.Name = "combxAdress";
            this.combxAdress.Size = new System.Drawing.Size(121, 21);
            this.combxAdress.TabIndex = 10;
            this.combxAdress.Text = "Choose your city";
            // 
            // rdFemale
            // 
            this.rdFemale.AutoSize = true;
            this.rdFemale.Location = new System.Drawing.Point(119, 139);
            this.rdFemale.Name = "rdFemale";
            this.rdFemale.Size = new System.Drawing.Size(59, 17);
            this.rdFemale.TabIndex = 9;
            this.rdFemale.TabStop = true;
            this.rdFemale.Text = "Female";
            this.rdFemale.UseVisualStyleBackColor = true;
            // 
            // rdMale
            // 
            this.rdMale.AutoSize = true;
            this.rdMale.Location = new System.Drawing.Point(119, 107);
            this.rdMale.Name = "rdMale";
            this.rdMale.Size = new System.Drawing.Size(48, 17);
            this.rdMale.TabIndex = 8;
            this.rdMale.TabStop = true;
            this.rdMale.Text = "Male";
            this.rdMale.UseVisualStyleBackColor = true;
            // 
            // txtAge
            // 
            this.txtAge.Location = new System.Drawing.Point(119, 62);
            this.txtAge.Name = "txtAge";
            this.txtAge.Size = new System.Drawing.Size(123, 20);
            this.txtAge.TabIndex = 7;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(119, 32);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(123, 20);
            this.txtName.TabIndex = 6;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(148, 385);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(77, 33);
            this.btnSubmit.TabIndex = 5;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // lblcoursses
            // 
            this.lblcoursses.AutoSize = true;
            this.lblcoursses.Location = new System.Drawing.Point(28, 228);
            this.lblcoursses.Name = "lblcoursses";
            this.lblcoursses.Size = new System.Drawing.Size(44, 13);
            this.lblcoursses.TabIndex = 4;
            this.lblcoursses.Text = "courses";
            this.lblcoursses.Click += new System.EventHandler(this.label5_Click);
            // 
            // lblAdress
            // 
            this.lblAdress.AutoSize = true;
            this.lblAdress.Location = new System.Drawing.Point(27, 188);
            this.lblAdress.Name = "lblAdress";
            this.lblAdress.Size = new System.Drawing.Size(45, 13);
            this.lblAdress.TabIndex = 3;
            this.lblAdress.Text = "Address";
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.Location = new System.Drawing.Point(27, 109);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(42, 13);
            this.lblGender.TabIndex = 2;
            this.lblGender.Text = "Gender";
            this.lblGender.Click += new System.EventHandler(this.label3_Click);
            // 
            // LblAge
            // 
            this.LblAge.AutoSize = true;
            this.LblAge.Location = new System.Drawing.Point(27, 69);
            this.LblAge.Name = "LblAge";
            this.LblAge.Size = new System.Drawing.Size(77, 13);
            this.LblAge.TabIndex = 1;
            this.LblAge.Text = "Enter your Age";
            this.LblAge.Click += new System.EventHandler(this.label2_Click);
            // 
            // LblName
            // 
            this.LblName.AutoSize = true;
            this.LblName.Location = new System.Drawing.Point(27, 35);
            this.LblName.Name = "LblName";
            this.LblName.Size = new System.Drawing.Size(86, 13);
            this.LblName.TabIndex = 0;
            this.LblName.Text = "Enter your Name";
            this.LblName.Click += new System.EventHandler(this.label1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(472, 473);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblcoursses;
        private System.Windows.Forms.Label lblAdress;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Label LblAge;
        private System.Windows.Forms.Label LblName;
        private System.Windows.Forms.TextBox txtAge;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.CheckedListBox chLstBxCourse;
        private System.Windows.Forms.ComboBox combxAdress;
        private System.Windows.Forms.RadioButton rdFemale;
        private System.Windows.Forms.RadioButton rdMale;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.AxHost;

namespace OsTask2
{     
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            form.Show();
            



            StreamWriter sw = new StreamWriter("info.txt");
            
                sw.WriteLine("Name: " + txtName.Text);
                sw.WriteLine("Age: " + txtAge.Text);
                if (rdMale.Checked == true)
                {
                    sw.WriteLine("Gender: Male");
                };
                if (rdFemale.Checked == true)
                {
                    sw.WriteLine("Gender: Female");
                };

                sw.WriteLine("Address: " + combxAdress.SelectedItem);

               
                string t = "";
                foreach (var  item in chLstBxCourse.CheckedItems)
                { t += item + ", "; };
                sw.WriteLine("Your Courses: " + t);
                sw.Close();
               



            


            

        }
    }
}

        